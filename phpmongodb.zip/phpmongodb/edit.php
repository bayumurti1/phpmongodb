<?php session_start();
   require 'config.php';
   if (isset($_GET['id'])) {
      $mhs = $collection->findOne(['_id' => new MongoDB\BSON\ObjectID($_GET['id'])]);
   }
   if(isset($_POST['submit'])){
      $collection->updateOne(
          ['_id' => new MongoDB\BSON\ObjectID($_GET['id'])],
          ['$set' => ['NIM' => $_POST['NIM'], 'Nama' => $_POST['Nama'], 
                      'Alamat' => $_POST['Alamat'],'Prodi' => $_POST['Prodi'],
          ]]
      );
      $_SESSION['success'] = "Data Mahasiswa berhasil diubah";
      header("Location: index.php");
   }
?>

<!DOCTYPE html>
<html>
   <head>
      <title>MongoDB</title>
      <link rel="stylesheet" href="./vendor/twbs/bootstrap/dist/css/bootstrap.min.css">
   </head>
   <body>
      <div class="container">
         <br>
         <CENTER><h1>Tambah Data Mahasiswa</h1></CENTER>
         <form method="POST">
            <div class="form-group">
                <label for="NIM"><strong>NIM:</strong></label>
                <input type="text" class="form-control" name="NIM" required="" value="<?php echo "$mhs->NIM"; ?>">
                <label for="Nama"><strong>Nama:</strong></label>
                <input type="text" class="form-control" name="Nama" placeholder="Nama Lengkap">
                <label for="Alamat"><strong>Alamat:</strong></label>
                <input type="text" class="form-control" name="Alamat" placeholder="Alamat">
                <label for="Prodi"><strong>Prodi:</strong></label>
                <select name="Prodi" id="Prodi" class="form-control">
                    <option value="MI">Manajemen Informatika</option>
                    <option value="KA">Komputerisasi Akuntasi</option>
                    <option value="TK">Teknik Komputer</option>
                    <option value="TI">Teknik Informatika</option>
                    <option value="SI">Sistem Informasi</option>
                </select>
                <br>
                <button type="submit" name="submit" class="btn btn-success">Ubah</button>
                <a href="index.php" class="btn btn-primary">Kembali</a>
            </div>
         </form>
      </div>
   </body>
</html>